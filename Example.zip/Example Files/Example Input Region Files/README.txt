Here the green X region signifies the coordinates of a gaseous structure that can be seen to move over time.
The purple X signifies the location of that same structure ~15 years later.
The background image represents the "older" image ("older" data). The "New" Image/data is not shown.